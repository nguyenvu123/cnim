<?php
include 'common.php';

?>

<div class="booking_padding_20 booking_font_20 booking_line_percent">
	
    <!-- logo -->
	<div><img src="<?php echo plugins_url('wp-booking-calendar/admin/');?>images/logo_admin.gif"  /></div>
	
	
               
</div>
<iframe name="iframe_submit" id="iframe_submit" style="border:none;display:none;height:0;width:0"></iframe>